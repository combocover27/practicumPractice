#!/usr/bin/env python3

'''
Name: 
Section:

Description of Program:
'''

######################################################################################################
# Import any required libraries here
######################################################################################################


def main():
    '''
    Function
    Name: main

    Function Description:
    '''
    # Read filename from command line argument
    # Open the input .asm file with that filename
    # Create and open the output .hack file with the same basename
    # Read each assembly instruction in the input file
    # For each instruction:
        # Parse the instruction into its type (A or C) and fields and return them in a tuple
        instruction_type, instruction_fields = Parser(instruction)
        # Generate the corresponding 16 bit binary code of that parsed instruction as a string
        machine_code = Code(instruction_type, instruction_fields)
        # Write that binary string to the output file

    # Be nice and close the files when you are done!

def Parser(inst):
    '''
    Function
    Name: Parser
    Inputs: 
    Outputs: 

    Function Description:
    '''
    # Your code here
    return # Return a tuple containing the instruction type and the separated fields

def Code(instType, instFields):

    '''
    Function
    Name: Code
    Inputs: 
    Outputs: 

    Function Description:
    '''
    # Your code here
    return    # Return the 16 bit string representing the machine code translation of the instruction


######################################################################################################
# Define any additional helper functions here (include fuction descriptions)
######################################################################################################


# Include the code below to automatically execute the main function when the program is run.
